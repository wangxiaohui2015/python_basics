from distutils.core import setup

setup(name='hello_package', version='1.0', description='This is a test hellp package',
      long_description='This is a test hellp package',
      author='WXH',
      author_email='wxhyzh2005@163.com', url='https://blog.csdn.net/funnyrand', py_modules=[
        'hello_package.fibonacci'])
